from playwright.sync_api import Page


class CinescopeRegisterPage:
    def __init__(self, page: Page):
        self.page = page
        self.url = "https://dev-cinescope.f5qa.ru/register"

        self.full_name_input = '[data-qa-id="register_full_name_input"]'
        self.email_input = '[data-qa-id="register_email_input"]'
        self.password_input = '[data-qa-id="register_password_input"]'
        self.repeat_password_input = '[data-qa-id="register_password_repeat_input"]'
        self.submit_button = '[data-qa-id="register_submit_button"]'

    def open(self):
        self.page.goto(self.url)

    def register(self, full_name: str, email: str, password: str):
        self.page.fill(self.full_name_input, full_name)
        self.page.fill(self.email_input, email)
        self.page.fill(self.password_input, password)
        self.page.fill(self.repeat_password_input, password)
        self.page.click(self.submit_button)

