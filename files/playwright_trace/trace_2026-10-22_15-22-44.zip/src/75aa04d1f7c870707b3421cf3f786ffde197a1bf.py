from random import randint

import pytest
from playwright.sync_api import Page, expect

from pages.register_page import CinescopeRegisterPage

pytestmark = pytest.mark.ui


def test_registration(page: Page):
    email = f"aqatest{randint(1, 999999)}@email.qa"

    register_page = CinescopeRegisterPage(page)
    register_page.open()
    register_page.register("Серега Серега", email, "qwerty123Q")

    expect(page.get_by_text("Подтвердите свою почту")).to_be_visible()